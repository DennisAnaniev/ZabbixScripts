#!/bin/bash
stat="1"

KERNEL=`uname -r | cut -d. -f1`
case $KERNEL in
  2)
  confname="ntp"
  ;;
  3)
  confname="chrony"
  ;;
  4)
  confname="chrony"
  ;;
esac

which ntpdate > /dev/null 2>&1
if [[ $? != 0 ]]; then echo "1"; exit 1; fi

for i in $(grep ^server /etc/${confname}.conf | awk '{print $2}'); do
    ntpdate -q $i > /dev/null 2>&1
    if [[ $? == 0 ]]; then stat="0"; fi
done
echo $stat
exit $stat

