#!/bin/sh
timestamp=$(date '+%s');
host="rsb-aspmos0ib1";
ATTRNAME='#EXECUTIONGROUP_MESSAGES';
DESCNAME="executiongroup.discovery";
OBJNAME="executiongroup.messages";
  
  OUTTEMP=queuestat.$$;
  JSONTEMP=jsontmp.$$;
    
    OUTJSON=/tmp/exgrp_messages.json;
      
      grep -E 'IBM\ Integration\ Bus.*(shutdown|Start)' /var/log/messages > $OUTTEMP;
      for queue in $(awk '{if ($NF == "shutdown.") { print $(NF-2) } else { queue=$10; sub(/^.*\./,"", queue); sub(/)$/, "", queue); print queue;} }' $OUTTEMP |sort |uniq); do
          echo $queue","$(grep $queue $OUTTEMP |tail -1) > $JSONTEMP;
          done;
          echo "$host ${DESCNAME} $timestamp {"$(awk -F, -v OBJNAME=${ATTRNAME} 'BEGIN {ORS=""; print "\"data\":["; sep=""; } {print sep"{\"{"OBJNAME"}\":\""$1"\"}"; sep=","} END { print "]"}' $JSONTEMP)"}" > $OUTJSON;
          awk -F, -v TST=$timestamp -v HOST=$host -v OBJNAME=${OBJNAME} '{ state=$2; gsub(/^.*\ BIP/,"BIP",state); gsub(/[[:punct:]]/,"",state); print HOST" "OBJNAME"["$1",State] "TST" "state }' $JSONTEMP >> $OUTJSON;
            
            rm $JSONTEMP $OUTTEMP;
            exit 0;