#!/bin/bash

echo 'DISPLAY QLOCAL(RB.SIEBELRT.OUT.ASYNC)' | runmqsc QM1 | grep CURDEPTH | awk '{print $2}' | sed 's/(/ /' | sed 's/)/ /' | awk '{print $2}'
