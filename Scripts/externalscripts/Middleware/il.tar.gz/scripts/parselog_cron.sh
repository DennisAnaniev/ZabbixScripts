#!/bin/bash
/bin/date
/etc/zabbix/scripts/parselog.sh
/usr/bin/zabbix_sender -z 10.45.129.32 -T -s rsb-aspmos0ib1 -i /tmp/exgrp_messages.json -- vv
