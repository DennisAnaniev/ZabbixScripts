#!/bin/bash

echo "display chstatus('RB.SIEBEL.SVRCONN') current" | runmqsc QM1 | grep ${1} | wc -l | grep -v mqsi | grep -v MQSI
