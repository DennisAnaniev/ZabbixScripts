#!/bin/bash
/bin/date
/etc/zabbix/scripts/exgroup.sh
/usr/bin/zabbix_sender -z 10.45.129.32 -T -s rsb-aspmos0ib1 -i /tmp/mqsilist_state.json -vv
