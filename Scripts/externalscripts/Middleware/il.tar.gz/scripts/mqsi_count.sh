#!/bin/sh

pc=`ps -ef | grep mqsi | wc -l`
echo $pc

