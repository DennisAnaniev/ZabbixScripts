#!/bin/sh
queuename=${1:-QM1};
tsfile=/tmp/$(basename $0).$$.timestamp;
tmpfile=/tmp/$(basename $0).$$.temp;
poolsfile=/tmp/export.${queuename}.pools;
/bin/date +'%s' > ${tsfile};
queuename=$queuename sh -c "echo display queue \(*\) | /opt/mqm/bin/runmqsc $queuename" | awk -F'[()]' '/QUEUE/ {print $2}' | (while read MQMQUEUE; do echo -n "$MQMQUEUE "; MQMQUEUE=$MQMQUEUE queuename=$queuename sh -c "echo DIS QL\($MQMQUEUE\) CURDEPTH | /opt/mqm/bin/runmqsc $queuename" | awk -F'[()]' -vcd=0 '/  CURDEPTH/ {if ($2 == "QLOCAL") cd=$4; else cd=$2; exit;} END {print cd;}'; done;) > ${tmpfile};
echo "$(hostname -s) queue.discovery $(<${tsfile}) {$(awk 'BEGIN {ORS=""; print "\"data\":["; sep=""; } {print sep"{\"{#QUEUE}\":\""$1"\"}"; sep=","} END { print "]"}' ${tmpfile})}" > ${poolsfile};
awk -v TST=$(<${tsfile}) -v HOST=$(hostname -s) '{ print HOST" queue.pool["$1",State] "TST" "$2 }' ${tmpfile} >> ${poolsfile};
rm -f ${tmpfile} ${tsfile};
