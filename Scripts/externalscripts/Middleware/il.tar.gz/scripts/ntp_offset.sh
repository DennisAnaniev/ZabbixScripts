#!/bin/bash
confname="ntp"
offset=0
which ntpdate > /dev/null 2>&1
if [[ $? != 0 ]]; then echo "1";  exit 1; fi
if [[  $(uname -r | cut -d. -f1) == 3 ]]; then confname="chrony"; fi
for i in $(grep ^server /etc/${confname}.conf | awk '{print $2}'); do
    offset_str=$(ntpdate -q $i 2> /dev/null)
    if [[ $? != 0 ]]; then echo "1"; exit 1; fi
    offset_cur=$(echo ${offset_str} | cut -d, -f3 | awk '{print (int($2) > 0 ? int($2) : -int($2))}')
    if [[  ${offset_cur} > ${offset} ]]; then  offset=${offset_cur}; fi
done
if [[ ${offset} -gt 2 ]]; then echo "1" ; exit 1; fi
echo "0"
exit 0

