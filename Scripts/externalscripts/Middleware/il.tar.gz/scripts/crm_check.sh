#!/bin/bash

echo "display chstatus('RB.SIEBEL.SVRCONN') current" | runmqsc QM1 | grep 'RB.SIEBEL.SVRCONN' | wc -l | grep -v mqsi | grep -v MQSI

