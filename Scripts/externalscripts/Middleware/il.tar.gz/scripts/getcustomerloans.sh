#!/bin/sh

proc_pid=`ps -ef | grep 'Acs.Get_GetCustomerLoans' | grep -v 'Acs.Get_GetCustomerLoans2' | grep -v 'Acs.Get_GetCustomerLoans3' | grep -v grep | grep -v '/bin/bash' | awk '{print $2}'`
#proc_pid=`ps -ef | grep 'Acs.Get_GetCustomerLoans' | grep -v grep | grep -v '/bin/bash' | awk '{print $2}'`
proc_path="/proc/$proc_pid/status"
#echo $proc_path
proc_mem=`cat $proc_path | grep VmSize | awk '{print $2}'`
proc_div=1024
mem_mb=`expr $proc_mem / $proc_div`
#echo $proc_pid
#echo $proc_mem
echo $mem_mb
