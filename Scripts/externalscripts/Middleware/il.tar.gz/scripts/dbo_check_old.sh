#!/bin/bash

echo "display chstatus('RB.DBO.SVRCONN') current" | runmqsc QM1 | grep 'RB.DBO.SVRCONN' | wc -l | grep -v mqsi | grep -v MQSI
