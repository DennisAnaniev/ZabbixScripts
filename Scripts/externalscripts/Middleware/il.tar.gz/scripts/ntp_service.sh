#!/bin/bash
if [[  $(uname -r | cut -d. -f1) == 2 ]]; then
    /etc/init.d/ntpd status  > /dev/null 2>&1
    else
    /bin/systemctl status chronyd.service  > /dev/null 2>&1
fi
if [[ $? == 0 ]]; then echo "0"; else echo "1"; fi
exit 0

