#!/bin/bash
/bin/date
if [ $# -ne 1 ]; then
    echo "Error: queue name required" >&2;
    exit 1;
fi;
/etc/zabbix/scripts/queue.sh $1;
/usr/bin/zabbix_sender -z 10.45.129.32 -T -s rsb-aspmos0ib1 -i /tmp/export.${1}.pools -vv