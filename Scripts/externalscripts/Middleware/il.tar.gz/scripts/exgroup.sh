#!/bin/bash
export PATH=$PATH:/opt/mqm/bin/:/opt/ibm/mqsi/9.0.0.10/bin/
. setmqenv -s
. mqsiprofile

OUTTEMP=/tmp/$(basename $0).$$.out
OUTJSON=/tmp/mqsilist_state.json

timestamp=$(date '+%s');
host="rsb-aspmos0ib1"

ATTRNAME='#EXECUTIONGROUP_STATE'
DESCNAME="executiongroup.discovery"
OBJNAME="executiongroup.state"

if ! /opt/ibm/mqsi/9.0.0.10/bin/mqsilist QM1MB | awk '/Execution/ {print $4","$NF;}' | sed -e "s/['.]//g" > $OUTTEMP; then
      echo "Error: mqsilist failed" >&2;
            exit 1;
            fi;
            
            echo "$host ${DESCNAME} $timestamp {"$(awk -F, -v OBJNAME=${ATTRNAME} 'BEGIN {ORS=""; print "\"data\":["; sep=""; } {print sep"{\"{"OBJNAME"}\":\""$1"\"}"; sep=","} END { print "]"}' $OUTTEMP)"}" > $OUTJSON;
            awk -F, -v TST=$timestamp -v HOST=$host -v OBJNAME=${OBJNAME} '{ print HOST" "OBJNAME"["$1",State] "TST" "$2 }' $OUTTEMP >> $OUTJSON;
            rm -f $OUTTEMP;
            exit 0;
                                                
